Topeka Font

The Topeka font is a sans-serif display font that resembles the Bing logo. I created this font entirely in FontLab Studio. It comes with alphanumeric punctuation, currency and international characters.
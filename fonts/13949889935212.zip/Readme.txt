Calligraserif Font

The Calligraserif font is a calligraphy and serif font that was designed with a calligraphy pen. It comes with alphanumeric characters, currency symbols, punctuation and international characters. This font is in the public domain and comes with a Euro sign.